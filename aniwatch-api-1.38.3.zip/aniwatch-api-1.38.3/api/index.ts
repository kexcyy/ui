import app from "../src/server.js";

export default app;
