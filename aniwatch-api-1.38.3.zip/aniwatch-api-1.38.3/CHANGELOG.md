## [1.38.3](https://github.com/ghoshRitesh12/aniwatch-api/compare/v1.38.2...v1.38.3) (2024-09-05)



## [1.38.2](https://github.com/ghoshRitesh12/aniwatch-api/compare/v1.38.1...v1.38.2) (2024-08-14)



## [1.38.1](https://github.com/ghoshRitesh12/aniwatch-api/compare/v1.38.0...v1.38.1) (2024-08-13)



# [1.38.0](https://github.com/ghoshRitesh12/aniwatch-api/compare/v1.37.0...v1.38.0) (2024-07-24)


### Features

* add `jname` field to Anime interface ([c65d786](https://github.com/ghoshRitesh12/aniwatch-api/commit/c65d786673c4369b8d617a6972d01b7ad3a51954))



# [1.37.0](https://github.com/ghoshRitesh12/aniwatch-api/compare/v1.36.3...v1.37.0) (2024-07-21)


### Bug Fixes

* added japanese anime names to all responses ([94664ab](https://github.com/ghoshRitesh12/aniwatch-api/commit/94664abdfdf1be8820f96afe081182f59281f4cb))


### Features

* added `mostPopular`, `mostFavorite` and `latestCompleted` to the home route response ([5d92946](https://github.com/ghoshRitesh12/aniwatch-api/commit/5d929461ce918006b9c3977e5af5f76799e820b3))
* added episode count to top airing anime ([62fa83a](https://github.com/ghoshRitesh12/aniwatch-api/commit/62fa83a56d5e5ea4cc5e7b38b478208b0c5e6a72))
* added episode number to estimated anime schedule ([bdfebb5](https://github.com/ghoshRitesh12/aniwatch-api/commit/bdfebb5e320c15ae9de1a57a66b6a4602bcebf4d))



