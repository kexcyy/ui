export type GenreAnimePathParams = {
  name?: string;
};

export type GenreAnimeQueryParams = {
  page?: string;
};
