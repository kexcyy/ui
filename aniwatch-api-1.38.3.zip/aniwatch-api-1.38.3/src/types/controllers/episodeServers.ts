export type EpisodeServersQueryParams = {
  episodeId?: string;
};
