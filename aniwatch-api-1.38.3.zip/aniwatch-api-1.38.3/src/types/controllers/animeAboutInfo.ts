export type AnimeAboutInfoQueryParams = {
  id?: string;
};
