export type AnimeSearchSuggestQueryParams = {
  q?: string;
};
