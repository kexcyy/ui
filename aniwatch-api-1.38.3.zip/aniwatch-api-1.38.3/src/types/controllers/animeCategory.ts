export type CategoryAnimePathParams = {
  category?: string;
};

export type CategoryAnimeQueryParams = {
  page?: string;
};
