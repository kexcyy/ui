export type AnimeProducerPathParams = {
  name?: string;
};

export type AnimeProducerQueryParams = {
  page?: string;
};
