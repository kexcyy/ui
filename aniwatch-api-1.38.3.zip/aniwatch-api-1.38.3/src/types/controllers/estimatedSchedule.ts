export type EstimatedScheduleQueryParams = {
  date?: string;
};
