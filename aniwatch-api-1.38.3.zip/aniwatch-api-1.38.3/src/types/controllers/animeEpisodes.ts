export type AnimeEpisodePathParams = {
  animeId?: string;
};
